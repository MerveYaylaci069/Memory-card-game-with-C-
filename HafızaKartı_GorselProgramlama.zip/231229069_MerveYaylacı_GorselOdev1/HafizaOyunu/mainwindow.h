/*#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QVector>
#include <QTimer>
#include <algorithm>
#include <random>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void kartTiklandi();  // Buton tıklama slotu

private:
    Ui::MainWindow *ui;

    QPushButton* butonlar[10];    // 10 buton
    QString kartResimleri[10];    // 10 kartın arka yüz resimleri
    QVector<int> acilanKartlar;   // Şu anda açılmış kartlar

    void karistirKartlar();       // Kartları karıştır
    void ayarlaButonlar();        // Butonları UI ile bağla
};
#endif // MAINWINDOW_H*/
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QLabel>
#include <QTimer>
#include <algorithm>
#include <random>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QPushButton* butonlar[10];
    QString kartResimleri[10];
    std::vector<int> acilanKartlar;

    QLabel* lblBasarisiz;
    int basarisizDenemeSayisi = 0;

    void ayarlaButonlar();
    void karistirKartlar();

private slots:
    void kartTiklandi();
};

#endif

