#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ayarlaButonlar();


    kartResimleri[0] = "C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP.jpeg";
    kartResimleri[1] = "C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP.jpeg";
    kartResimleri[2] = "C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP (1).jpeg";
    kartResimleri[3] = "C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP (1).jpeg";
    kartResimleri[4] = "C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP (2).jpeg";
    kartResimleri[5] = "C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP (2).jpeg";
    kartResimleri[6] = "C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP (4).jpeg";
    kartResimleri[7] = "C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP (4).jpeg";
    kartResimleri[8] = "C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP (3).jpeg";
    kartResimleri[9] = "C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP (3).jpeg";

    karistirKartlar();


    lblBasarisiz = new QLabel(this);
    lblBasarisiz->setText("Başarısız deneme: 0");
    lblBasarisiz->setGeometry(20, 420, 200, 30);
    lblBasarisiz->setStyleSheet("font-weight: bold; font-size: 14px;");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::ayarlaButonlar()
{
    butonlar[0] = ui->btn1;
    butonlar[1] = ui->btn2;
    butonlar[2] = ui->btn3;
    butonlar[3] = ui->btn4;
    butonlar[4] = ui->btn5;
    butonlar[5] = ui->btn6;
    butonlar[6] = ui->btn7;
    butonlar[7] = ui->btn8;
    butonlar[8] = ui->btn9;
    butonlar[9] = ui->btn10;

    QPixmap backPix("C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP (5).jpeg");

    for(int i = 0; i < 10; i++)
    {
        butonlar[i]->setIcon(QIcon(backPix));
        butonlar[i]->setIconSize(QSize(100,100));
        butonlar[i]->setText("");
        connect(butonlar[i], &QPushButton::clicked, this, &MainWindow::kartTiklandi);
        butonlar[i]->setProperty("kilitli", false);
    }
}

void MainWindow::karistirKartlar()
{
    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(std::begin(kartResimleri), std::end(kartResimleri), g);
}

void MainWindow::kartTiklandi()
{
    QPushButton* senderBtn = qobject_cast<QPushButton*>(sender());
    if(!senderBtn) return;

    if(senderBtn->property("kilitli").toBool()) return;

    int index = -1;
    for(int i = 0; i < 10; i++)
    {
        if(butonlar[i] == senderBtn) { index = i; break; }
    }
    if(index == -1) return;

    QPixmap pix(kartResimleri[index]);
    butonlar[index]->setIcon(QIcon(pix));

    butonlar[index]->setProperty("kilitli", true);
    acilanKartlar.push_back(index);

    if(acilanKartlar.size() == 2)
    {
        int first = acilanKartlar[0];
        int second = acilanKartlar[1];

        if(kartResimleri[first] == kartResimleri[second])
        {

            acilanKartlar.clear();
        }
        else
        {

            basarisizDenemeSayisi++;
            lblBasarisiz->setText("Başarısız deneme: " + QString::number(basarisizDenemeSayisi));

            QTimer::singleShot(1500, this, [=](){
                QPixmap backPix("C:/Users/CASPER/OneDrive - ktun.edu.tr/Belgeler/HafizaOyunu/images/OIP (5).jpeg");
                butonlar[first]->setIcon(QIcon(backPix));
                butonlar[second]->setIcon(QIcon(backPix));

                butonlar[first]->setProperty("kilitli", false);
                butonlar[second]->setProperty("kilitli", false);

                acilanKartlar.clear();
            });
        }
    }
}
